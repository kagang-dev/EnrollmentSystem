```php
<?php

include "db.php";


// ==========================================
// STUDENTS
// ==========================================

// ADD STUDENT
if (isset($_POST["add_student"])) {

    $studentID = $_POST["StudentID"];
    $name = $_POST["Name"];
    $age = $_POST["Age"];
    $email = $_POST["Email"];

    $sql = "INSERT INTO Students
            (StudentID, Name, Age, Email)
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isis", $studentID, $name, $age, $email);

    if ($stmt->execute()) {
        header("Location: index.php?section=students&success=Student added successfully");
    } else {
        header("Location: index.php?section=students&error=" . urlencode($stmt->error));
    }

    exit();
}


// UPDATE STUDENT
if (isset($_POST["update_student"])) {

    $studentID = $_POST["StudentID"];
    $name = $_POST["Name"];
    $age = $_POST["Age"];
    $email = $_POST["Email"];

    $sql = "UPDATE Students
            SET Name = ?, Age = ?, Email = ?
            WHERE StudentID = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sisi", $name, $age, $email, $studentID);

    if ($stmt->execute()) {
        header("Location: index.php?section=students&success=Student updated successfully");
    } else {
        header("Location: index.php?section=students&error=" . urlencode($stmt->error));
    }

    exit();
}


// DELETE STUDENT
if (isset($_GET["delete_student"])) {

    $studentID = $_GET["delete_student"];

    $sql = "DELETE FROM Students WHERE StudentID = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentID);

    if ($stmt->execute()) {
        header("Location: index.php?section=students&success=Student deleted successfully");
    } else {
        header("Location: index.php?section=students&error=Cannot delete student. The student may have enrollment records.");
    }

    exit();
}



// ==========================================
// COURSES
// ==========================================

// ADD COURSE
if (isset($_POST["add_course"])) {

    $courseID = $_POST["CourseID"];
    $courseName = $_POST["CourseName"];

    $sql = "INSERT INTO Courses
            (CourseID, CourseName)
            VALUES (?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $courseID, $courseName);

    if ($stmt->execute()) {
        header("Location: index.php?section=courses&success=Course added successfully");
    } else {
        header("Location: index.php?section=courses&error=" . urlencode($stmt->error));
    }

    exit();
}


// UPDATE COURSE
if (isset($_POST["update_course"])) {

    $courseID = $_POST["CourseID"];
    $courseName = $_POST["CourseName"];

    $sql = "UPDATE Courses
            SET CourseName = ?
            WHERE CourseID = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $courseName, $courseID);

    if ($stmt->execute()) {
        header("Location: index.php?section=courses&success=Course updated successfully");
    } else {
        header("Location: index.php?section=courses&error=" . urlencode($stmt->error));
    }

    exit();
}


// DELETE COURSE
if (isset($_GET["delete_course"])) {

    $courseID = $_GET["delete_course"];

    $sql = "DELETE FROM Courses WHERE CourseID = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $courseID);

    if ($stmt->execute()) {
        header("Location: index.php?section=courses&success=Course deleted successfully");
    } else {
        header("Location: index.php?section=courses&error=Cannot delete course. The course may have enrollment records.");
    }

    exit();
}



// ==========================================
// ENROLLMENTS
// ==========================================

// ADD ENROLLMENT
if (isset($_POST["add_enrollment"])) {

    $enrollmentID = $_POST["EnrollmentID"];
    $studentID = $_POST["StudentID"];
    $courseID = $_POST["CourseID"];

    $sql = "INSERT INTO Enrollments
            (EnrollmentID, StudentID, CourseID)
            VALUES (?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $enrollmentID, $studentID, $courseID);

    if ($stmt->execute()) {
        header("Location: index.php?section=enrollments&success=Student enrolled successfully");
    } else {
        header("Location: index.php?section=enrollments&error=" . urlencode($stmt->error));
    }

    exit();
}


// UPDATE ENROLLMENT
if (isset($_POST["update_enrollment"])) {

    $enrollmentID = $_POST["EnrollmentID"];
    $studentID = $_POST["StudentID"];
    $courseID = $_POST["CourseID"];

    $sql = "UPDATE Enrollments
            SET StudentID = ?, CourseID = ?
            WHERE EnrollmentID = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $studentID, $courseID, $enrollmentID);

    if ($stmt->execute()) {
        header("Location: index.php?section=enrollments&success=Enrollment updated successfully");
    } else {
        header("Location: index.php?section=enrollments&error=" . urlencode($stmt->error));
    }

    exit();
}


// DELETE ENROLLMENT
if (isset($_GET["delete_enrollment"])) {

    $enrollmentID = $_GET["delete_enrollment"];

    $sql = "DELETE FROM Enrollments WHERE EnrollmentID = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $enrollmentID);

    if ($stmt->execute()) {
        header("Location: index.php?section=enrollments&success=Enrollment deleted successfully");
    } else {
        header("Location: index.php?section=enrollments&error=" . urlencode($stmt->error));
    }

    exit();
}

?>
```
