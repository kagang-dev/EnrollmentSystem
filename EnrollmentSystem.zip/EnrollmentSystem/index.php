```php
<?php

include "db.php";


// Get selected section
$section = $_GET["section"] ?? "students";


// ==========================================
// GET STUDENTS
// ==========================================

$students = $conn->query("
    SELECT *
    FROM Students
    ORDER BY StudentID
");


// ==========================================
// GET COURSES
// ==========================================

$courses = $conn->query("
    SELECT *
    FROM Courses
    ORDER BY CourseID
");


// ==========================================
// GET ENROLLMENTS
// ==========================================

$enrollments = $conn->query("
    SELECT
        e.EnrollmentID,
        e.StudentID,
        e.CourseID,
        s.Name,
        c.CourseName
    FROM Enrollments e
    INNER JOIN Students s
        ON e.StudentID = s.StudentID
    INNER JOIN Courses c
        ON e.CourseID = c.CourseID
    ORDER BY e.EnrollmentID
");


// Messages
$success = $_GET["success"] ?? "";
$error = $_GET["error"] ?? "";

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Enrollment System</title>

    <link rel="stylesheet"
          href="style.css?v=2">

</head>


<body>


<div class="container">


    <!-- =========================
         SIDEBAR
    ========================== -->

    <aside class="sidebar">


        <div class="logo">

            <div class="logo-icon">
                E
            </div>

            <div>
                <h2>EnrollSys</h2>
                <span>Management System</span>
            </div>

        </div>


        <nav>

            <a href="index.php?section=students"
               class="nav-item <?= $section == 'students' ? 'active' : '' ?>">

                <span>👨‍🎓</span>
                Students

            </a>


            <a href="index.php?section=courses"
               class="nav-item <?= $section == 'courses' ? 'active' : '' ?>">

                <span>📚</span>
                Courses

            </a>


            <a href="index.php?section=enrollments"
               class="nav-item <?= $section == 'enrollments' ? 'active' : '' ?>">

                <span>📝</span>
                Enrollments

            </a>

        </nav>


        <div class="sidebar-bottom">

            <p>Enrollment System</p>

            <small>
                PHP + MySQL CRUD
            </small>

        </div>


    </aside>



    <!-- =========================
         MAIN CONTENT
    ========================== -->

    <main class="main-content">


        <!-- HEADER -->

        <header class="topbar">

            <div>

                <p class="welcome">
                    Welcome back 👋
                </p>

                <h1>

                    <?php

                    if ($section == "students") {
                        echo "Students";
                    }

                    elseif ($section == "courses") {
                        echo "Courses";
                    }

                    else {
                        echo "Enrollments";
                    }

                    ?>

                </h1>

            </div>


            <div class="profile">

                <div class="avatar">
                    A
                </div>

                <div>

                    <strong>
                        Administrator
                    </strong>

                    <small>
                        Admin
                    </small>

                </div>

            </div>

        </header>



        <!-- =========================
             MESSAGES
        ========================== -->

        <?php if ($success): ?>

            <div class="alert success">
                ✓ <?= htmlspecialchars($success) ?>
            </div>

        <?php endif; ?>


        <?php if ($error): ?>

            <div class="alert error">
                ⚠ <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>



        <!-- =========================
             STUDENTS
        ========================== -->

        <?php if ($section == "students"): ?>


        <section>


            <div class="section-header">

                <div>

                    <h2>
                        Student Management
                    </h2>

                    <p>
                        Add, update, view, and delete student records.
                    </p>

                </div>

            </div>



            <!-- STUDENT FORM -->

            <div class="card">


                <form action="action.php"
                      method="POST">


                    <div class="form-grid">


                        <div class="input-group">

                            <label>
                                Student ID
                            </label>

                            <input
                                type="number"
                                name="StudentID"
                                placeholder="Enter student ID"
                                required>

                        </div>


                        <div class="input-group">

                            <label>
                                Student Name
                            </label>

                            <input
                                type="text"
                                name="Name"
                                placeholder="Enter student name"
                                required>

                        </div>


                        <div class="input-group">

                            <label>
                                Age
                            </label>

                            <input
                                type="number"
                                name="Age"
                                placeholder="Enter age"
                                required>

                        </div>


                        <div class="input-group">

                            <label>
                                Email
                            </label>

                            <input
                                type="email"
                                name="Email"
                                placeholder="Enter email"
                                required>

                        </div>


                    </div>



                    <div class="buttons">


                        <button
                            type="submit"
                            name="add_student"
                            class="btn primary">

                            + Add Student

                        </button>


                        <button
                            type="submit"
                            name="update_student"
                            class="btn update">

                            Update

                        </button>


                        <button
                            type="reset"
                            class="btn clear">

                            Clear

                        </button>


                    </div>


                </form>


            </div>



            <!-- STUDENT TABLE -->

            <div class="card table-card">


                <div class="table-header">

                    <div>

                        <h3>
                            Student Records
                        </h3>

                        <p>
                            Records stored in schooldb
                        </p>

                    </div>

                </div>


                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>
                                    Student ID
                                </th>

                                <th>
                                    Name
                                </th>

                                <th>
                                    Age
                                </th>

                                <th>
                                    Email
                                </th>

                                <th>
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php while ($row = $students->fetch_assoc()): ?>


                            <tr>

                                <td>
                                    <?= htmlspecialchars($row["StudentID"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["Name"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["Age"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["Email"]) ?>
                                </td>

                                <td>

                                    <a
                                        class="delete-link"
                                        href="action.php?delete_student=<?= $row["StudentID"] ?>"
                                        onclick="return confirm('Delete this student?')">

                                        Delete

                                    </a>

                                </td>

                            </tr>


                        <?php endwhile; ?>


                        </tbody>


                    </table>


                </div>


            </div>


        </section>


        <?php endif; ?>



        <!-- =========================
             COURSES
        ========================== -->

        <?php if ($section == "courses"): ?>


        <section>


            <div class="section-header">

                <h2>
                    Course Management
                </h2>

                <p>
                    Manage available courses.
                </p>

            </div>



            <div class="card">


                <form action="action.php"
                      method="POST">


                    <div class="form-grid">


                        <div class="input-group">

                            <label>
                                Course ID
                            </label>

                            <input
                                type="number"
                                name="CourseID"
                                placeholder="Enter course ID"
                                required>

                        </div>


                        <div class="input-group">

                            <label>
                                Course Name
                            </label>

                            <input
                                type="text"
                                name="CourseName"
                                placeholder="Enter course name"
                                required>

                        </div>


                    </div>


                    <div class="buttons">


                        <button
                            type="submit"
                            name="add_course"
                            class="btn primary">

                            + Add Course

                        </button>


                        <button
                            type="submit"
                            name="update_course"
                            class="btn update">

                            Update

                        </button>


                        <button
                            type="reset"
                            class="btn clear">

                            Clear

                        </button>


                    </div>


                </form>


            </div>



            <!-- COURSE TABLE -->

            <div class="card table-card">


                <div class="table-header">

                    <div>

                        <h3>
                            Course Records
                        </h3>

                        <p>
                            Courses stored in schooldb
                        </p>

                    </div>

                </div>


                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>
                                    Course ID
                                </th>

                                <th>
                                    Course Name
                                </th>

                                <th>
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php while ($row = $courses->fetch_assoc()): ?>


                            <tr>

                                <td>
                                    <?= htmlspecialchars($row["CourseID"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["CourseName"]) ?>
                                </td>

                                <td>

                                    <a
                                        class="delete-link"
                                        href="action.php?delete_course=<?= $row["CourseID"] ?>"
                                        onclick="return confirm('Delete this course?')">

                                        Delete

                                    </a>

                                </td>

                            </tr>


                        <?php endwhile; ?>


                        </tbody>


                    </table>


                </div>


            </div>


        </section>


        <?php endif; ?>



        <!-- =========================
             ENROLLMENTS
        ========================== -->

        <?php if ($section == "enrollments"): ?>


        <section>


            <div class="section-header">

                <h2>
                    Enrollment Management
                </h2>

                <p>
                    Enroll students in available courses.
                </p>

            </div>



            <!-- ENROLLMENT FORM -->

            <div class="card">


                <form action="action.php"
                      method="POST">


                    <div class="form-grid">


                        <div class="input-group">

                            <label>
                                Enrollment ID
                            </label>

                            <input
                                type="number"
                                name="EnrollmentID"
                                placeholder="Enter enrollment ID"
                                required>

                        </div>


                        <div class="input-group">

                            <label>
                                Student
                            </label>

                            <select name="StudentID"
                                    required>

                                <option value="">
                                    Select student
                                </option>


                                <?php

                                $studentOptions = $conn->query(
                                    "SELECT * FROM Students ORDER BY Name"
                                );

                                while ($student = $studentOptions->fetch_assoc()):

                                ?>

                                <option value="<?= $student["StudentID"] ?>">

                                    <?= htmlspecialchars($student["Name"]) ?>

                                </option>

                                <?php endwhile; ?>


                            </select>

                        </div>


                        <div class="input-group">

                            <label>
                                Course
                            </label>

                            <select name="CourseID"
                                    required>

                                <option value="">
                                    Select course
                                </option>


                                <?php

                                $courseOptions = $conn->query(
                                    "SELECT * FROM Courses ORDER BY CourseName"
                                );

                                while ($course = $courseOptions->fetch_assoc()):

                                ?>

                                <option value="<?= $course["CourseID"] ?>">

                                    <?= htmlspecialchars($course["CourseName"]) ?>

                                </option>

                                <?php endwhile; ?>


                            </select>

                        </div>


                    </div>



                    <div class="buttons">


                        <button
                            type="submit"
                            name="add_enrollment"
                            class="btn primary">

                            + Enroll Student

                        </button>


                        <button
                            type="submit"
                            name="update_enrollment"
                            class="btn update">

                            Update

                        </button>


                        <button
                            type="reset"
                            class="btn clear">

                            Clear

                        </button>


                    </div>


                </form>


            </div>



            <!-- ENROLLMENT TABLE -->

            <div class="card table-card">


                <div class="table-header">

                    <div>

                        <h3>
                            Enrollment Records
                        </h3>

                        <p>
                            Student-course relationships
                        </p>

                    </div>

                </div>


                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>
                                    Enrollment ID
                                </th>

                                <th>
                                    Student
                                </th>

                                <th>
                                    Course
                                </th>

                                <th>
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php while ($row = $enrollments->fetch_assoc()): ?>


                            <tr>

                                <td>
                                    <?= htmlspecialchars($row["EnrollmentID"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["Name"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["CourseName"]) ?>
                                </td>

                                <td>

                                    <a
                                        class="delete-link"
                                        href="action.php?delete_enrollment=<?= $row["EnrollmentID"] ?>"
                                        onclick="return confirm('Delete this enrollment?')">

                                        Delete

                                    </a>

                                </td>

                            </tr>


                        <?php endwhile; ?>


                        </tbody>


                    </table>


                </div>


            </div>


        </section>


        <?php endif; ?>


    </main>


</div>


</body>

</html>
```
